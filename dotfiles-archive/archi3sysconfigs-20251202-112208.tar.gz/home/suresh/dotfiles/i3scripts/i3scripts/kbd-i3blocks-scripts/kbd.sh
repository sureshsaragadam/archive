
#!/bin/bash
layout=$(xkb-switch)
echo "$layout"
