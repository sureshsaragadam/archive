
-- LOAD PLAIN CONFIG FILES
require("config.options")
require("config.keymaps")
require("config.autocmds")
