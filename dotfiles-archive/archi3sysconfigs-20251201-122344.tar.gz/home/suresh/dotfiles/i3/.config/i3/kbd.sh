
#!/bin/bash
pkill -RTMIN+1 i3blocks
