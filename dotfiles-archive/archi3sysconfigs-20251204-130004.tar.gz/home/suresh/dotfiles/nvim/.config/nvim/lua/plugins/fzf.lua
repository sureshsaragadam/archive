return {
	"junegunn/fzf",
	enabled = true,
	build = "./install --bin",
	"junegunn/fzf.vim",
}
